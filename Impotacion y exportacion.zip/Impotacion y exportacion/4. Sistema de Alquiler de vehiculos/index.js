import Vehiculo from "./Vehiculo.js"
import Clientes from "./Clientes.js"
import Alquileres from "./Alquileres.js"
