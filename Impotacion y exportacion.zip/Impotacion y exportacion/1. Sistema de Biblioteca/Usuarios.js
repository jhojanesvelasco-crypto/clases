class Usuarios {
    nombre
    apellido
    direccion
    telefono

    constructor(nombre, apellido, direccion, telefono) {
        this.nombre = nombre
        this.apellido = apellido
        this.direccion = direccion
        this.telefono = telefono
    }

    verInfo() {
        console.log("Nombre: " + this.nombre + " " + this.apellido + " | Dirección: " + this.direccion + " | Teléfono: " + this.telefono)
    }
}

export default Usuarios