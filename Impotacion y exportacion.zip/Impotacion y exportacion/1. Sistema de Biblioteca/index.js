// una Biblioteca necesita desarrollar un sistema basico que permita
// prestamo de los libros a quien se le a prestado
// y que libros a prestado
// sustantivos=> quien necesita interactuar
//historias de usuario
// Libros,Usuarios,Prestato

import Libros from "./Libros.js"
import Prestamos from "./Prestamos.js"
import Usuarios from "./Usuarios.js"

// instancias

let quijote = new Libros("El Quijote", "Norma", "Miguel de Cervantes")
let maria = new Libros("La Maria", "Norma", "Jorge Isaacs")

quijote.verLibro()
maria.verLibro()

let alexa = new Usuarios("Alexandra", "Muños", "111", "123")
alexa.verInfo()

let prestarQuijoteMaria = new Prestamos(alexa, "2/10/2026", "5/10/2026")
prestarQuijoteMaria.registrarLibros(quijote)
prestarQuijoteMaria.registrarLibros(maria)

prestarQuijoteMaria.verlibro()
alexa.verInfo()