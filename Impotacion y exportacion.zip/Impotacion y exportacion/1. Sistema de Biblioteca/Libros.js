class Libros {
    nombre
    editorial
    autor

    constructor(nombre, editorial, autor) {
        this.nombre = nombre
        this.editorial = editorial
        this.autor = autor
    }

    registrarNombre(nuevoNombre) {
        this.nombre = nuevoNombre
    }

    registrarEditorial(nuevoEditorial) {
        this.editorial = nuevoEditorial
    }

    registrarAutor(nuevoAutor) {
        this.autor = nuevoAutor
    }

    verLibro() {
        console.log("Nombre Libro: " + this.nombre + " | editorial: " + this.editorial + " | autor: " + this.autor)
    }
}

export default Libros