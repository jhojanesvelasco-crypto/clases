import Libros from "./Libros.js";

class Prestamos {
    
    fechaPrestamo
    fechaDevolucion

    constructor(usuario, fechaPrestamo, fechaDevolucion) {
        this.usuario = usuario
        this.fechaPrestamo = fechaPrestamo
        this.fechaDevolucion = fechaDevolucion
        this.libros = [];
    }

    registrarLibros(libro) {
        this.libros.push(libro)
    }

    verlibro() {

        for (let i = 0; i < this.libros.length; i++) {
            console.log(this.libros[i].nombre + " | fecha Prestamo:", this.fechaPrestamo)
        }
    }
}

export default Prestamos