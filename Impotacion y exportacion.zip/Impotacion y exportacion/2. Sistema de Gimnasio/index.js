import Clientes from "./cliente.js"
import Entrenadores from "./entrenador.js"
import Rutinas from "./rutina.js"

// instancias

let juan = new Clientes("Juan", "111", "123", 20)
let maria = new Clientes("Maria", "222", "456", 25)

juan.verInfo()
maria.verInfo()

let carlos = new Entrenadores("Carlos", "Musculación", "789")
let andrea = new Entrenadores("Andrea", "Cardio", "321")

carlos.verInfo()
andrea.verInfo()

let rutinaFuerza = new Rutinas("Fuerza", "Aumentar masa muscular", "60 minutos", carlos)
let rutinaCardio = new Rutinas("Cardio", "Mejorar resistencia", "40 minutos", andrea)

rutinaFuerza.verRutina()
rutinaCardio.verRutina()

juan.registrarRutina(rutinaFuerza)
juan.registrarRutina(rutinaCardio)

maria.registrarRutina(rutinaCardio)

juan.verInfo()
maria.verInfo()