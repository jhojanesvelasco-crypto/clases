class Clientes {
    nombre
    documento
    telefono
    edad

    constructor(nombre, documento, telefono, edad) {
        this.nombre = nombre
        this.documento = documento
        this.telefono = telefono
        this.edad = edad
        this.rutinas = []
    }

    registrarRutina(rutina) {
        this.rutinas.push(rutina)
    }

    verInfo() {
        console.log("Nombre: " + this.nombre + " | Documento: " + this.documento + " | Teléfono: " + this.telefono + " | Edad: " + this.edad)

        for (let i = 0; i < this.rutinas.length; i++) {
            console.log("Rutina: " + this.rutinas[i].nombre)
        }
    }
}

export default Clientes