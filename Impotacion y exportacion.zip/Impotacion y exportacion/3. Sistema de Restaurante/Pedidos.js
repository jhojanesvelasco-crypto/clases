class Pedidos {
    fecha
    numeroPedido

    constructor(fecha, numeroPedido, cliente) {
        this.fecha = fecha
        this.numeroPedido = numeroPedido
        this.cliente = cliente
        this.platos = []
    }

    registrarPlato(plato) {
        this.platos.push(plato)
    }

    verPedido() {
        console.log("Número de pedido: " + this.numeroPedido)
        console.log("Fecha: " + this.fecha)
        console.log("Cliente: " + this.cliente.nombre)

        for (let i = 0; i < this.platos.length; i++) {
            console.log("Plato solicitado: " + this.platos[i].nombre)
        }
    }
}

export default Pedidos