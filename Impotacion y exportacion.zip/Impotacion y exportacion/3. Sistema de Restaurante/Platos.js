class Platos {
    nombre
    categoria
    precio
    disponibilidad

    constructor(nombre, categoria, precio, disponibilidad) {
        this.nombre = nombre
        this.categoria = categoria
        this.precio = precio
        this.disponibilidad = disponibilidad
    }

    verPlato() {
        console.log("Plato: " + this.nombre + " | Categoría: " + this.categoria + " | Precio: " + this.precio + " | Disponibilidad: " + this.disponibilidad)
    }
}

export default Platos