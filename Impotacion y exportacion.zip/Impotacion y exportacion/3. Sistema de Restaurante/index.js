import Platos from "./Platos.js"
import Clientes from "./Clientes.js"
import Pedidos from "./Pedidos.js"

// instancias

let hamburguesa = new Platos("Hamburguesa", "Comida rápida", 15000, true)
let pizza = new Platos("Pizza", "Comida italiana", 20000, true)
let ensalada = new Platos("Ensalada", "Saludable", 12000, true)

hamburguesa.verPlato()
pizza.verPlato()
ensalada.verPlato()

let alexa = new Clientes("Alexandra", "111", "123")
let juan = new Clientes("Juan", "222", "456")

alexa.verInfo()
juan.verInfo()

let pedidoAlexa = new Pedidos("2/10/2026", "001", alexa)
pedidoAlexa.registrarPlato(hamburguesa)
pedidoAlexa.registrarPlato(pizza)

let pedidoJuan = new Pedidos("2/10/2026", "002", juan)
pedidoJuan.registrarPlato(pizza)
pedidoJuan.registrarPlato(ensalada)

alexa.registrarPedido(pedidoAlexa)
juan.registrarPedido(pedidoJuan)

pedidoAlexa.verPedido()
pedidoJuan.verPedido()