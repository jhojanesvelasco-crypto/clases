class Clientes {
    nombre
    documento
    telefono

    constructor(nombre, documento, telefono) {
        this.nombre = nombre
        this.documento = documento
        this.telefono = telefono
        this.pedidos = []
    }

    registrarPedido(pedido) {
        this.pedidos.push(pedido)
    }

    verInfo() {
        console.log("Nombre: " + this.nombre + " | Documento: " + this.documento + " | Teléfono: " + this.telefono)
    }
}

export default Clientes